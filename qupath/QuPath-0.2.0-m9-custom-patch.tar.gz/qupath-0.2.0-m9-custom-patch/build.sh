rm -rf build
./gradlew createPackage -Ppackager=/opt/jdk-14/bin/jpackage
